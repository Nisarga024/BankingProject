package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class FundTransferNotFoundException extends Throwable
{
	public FundTransferNotFoundException(String msg) 
	{
		super(msg);
	} 

}
