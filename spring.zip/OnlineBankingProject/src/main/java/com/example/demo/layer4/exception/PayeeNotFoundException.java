package com.example.demo.layer4.exception;


@SuppressWarnings("serial")
public class PayeeNotFoundException extends Throwable
{
	public PayeeNotFoundException(String msg)
	{
		super(msg);
	}

}
