package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.CustomerDTO;	
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;



@Service
public interface CustomerService 
{
	String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException;
	String addCustomerService(CustomerDTO custRef) throws CustomerAlreadyExistsException;
	Customer findCustomerService(int custNo)throws CustomerNotFoundException ;
	Customer findSignupService(int custid)throws CustomerNotFoundException ;
	Set<Customer>findAllCustomersService(); 	
	Set<Customer> findCustomerbyServiceNo(int serviceNo);
	Customer athentication(int custid,String password)throws CustomerNotFoundException;

}