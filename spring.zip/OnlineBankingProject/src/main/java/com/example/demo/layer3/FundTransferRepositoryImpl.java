package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.FundTransfer;

@Repository
public class FundTransferRepositoryImpl implements FundTransferRepository
{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
										
	
	@Transactional//no need of begin transaction and commit rollback
	public void  addTransaction(FundTransfer fundtransferRef) //usesA
	{
		entityManager.persist(fundtransferRef);
	}
	
	@Transactional
	public FundTransfer findTransaction(int fundNo)//producesA transaction obj
	{
		System.out.println("Transaction repo....NO scope of bussiness logic here...");
		return entityManager.find(FundTransfer.class,fundNo);
		
	}

	@Transactional
	public Set<FundTransfer> findAllTransactions() 
	{
		List<FundTransfer> fundlist = new ArrayList<FundTransfer>();
		TypedQuery<FundTransfer> query = entityManager.createNamedQuery("FundTransfer.findAll",FundTransfer.class);
		fundlist=query.getResultList();
		Set<FundTransfer> rSet = new HashSet<FundTransfer>(fundlist);
		return rSet;
	}

	@SuppressWarnings({"unchecked","rawtypes"})
	@Transactional
	public Set<FundTransfer> findTransactionByCustId(int custId)
	{
		Set<FundTransfer> fundSet;
		fundSet = new HashSet<FundTransfer>();
		Query query = entityManager.createNativeQuery("select * from fundTransfer where cust_id =:mycust_id",FundTransfer.class).setParameter("mycust_id", custId);
		fundSet =new HashSet(query.getResultList());
					
		return fundSet;
	}
	
	@SuppressWarnings({"unchecked","rawtypes"})
	@Transactional
	public Set<FundTransfer> findTransactionByPayeeId(int payeeId)
	{
		Set<FundTransfer> fundSet;
		fundSet = new HashSet<FundTransfer>();
		Query query = entityManager.createNativeQuery("select * from fundTransfer where payee_id =:mypayee_id",FundTransfer.class).setParameter("mypayee_id", payeeId);
		fundSet =new HashSet(query.getResultList());
					
		return fundSet;
	}

//	@Transactional
//	public void removeTransaction(int fundNo) {
//		FundTransfer fundTemp = entityManager.find(FundTransfer.class,fundNo);
//		entityManager.remove(fundTemp);
//		
//	}
	
	
	
}