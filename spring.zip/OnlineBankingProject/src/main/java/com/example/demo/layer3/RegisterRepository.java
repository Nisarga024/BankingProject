package com.example.demo.layer3;

import java.util.Set;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.Register;

@Repository
public interface RegisterRepository
{
	void addRegistration(Register registerRef);   //adding registration
	Set<Register>findRegistration();    			//finding all registration
	Register findRegistration(int register);		//finding Single registration
	
		
}
