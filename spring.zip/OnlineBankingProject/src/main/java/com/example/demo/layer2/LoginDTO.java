package com.example.demo.layer2;

public class LoginDTO {
	private int custId;
	private String iniPassword;
	
	public LoginDTO() {
		super();
		System.out.println("Login constructor()");
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getIniPassword() {
		return iniPassword;
	}
	public void setIniPassword(String iniPassword) {
		this.iniPassword = iniPassword;
	}
	
	
}
