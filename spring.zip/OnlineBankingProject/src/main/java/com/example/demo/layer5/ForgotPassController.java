package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.ForgotPass;
import com.example.demo.layer4.ForgotPassService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ForgotPassController
{
	@Autowired
	ForgotPassService passwordServ;
	
	@DeleteMapping(path="/deletePass")
	public String removeForgotPass(@RequestBody ForgotPass pass)
	{  		
		String stmsg = null;
		try
		{
			stmsg = passwordServ.removeForgotPasswordIdService(pass.getSecurityId());
		} 

		catch(Exception e) 
		{
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		return stmsg;
		
	}
	@GetMapping(path="/getForgotPasses")
	@ResponseBody
	public Set<ForgotPass> getAllPasswordId() 
	{		
		Set<ForgotPass> passList = passwordServ.findAllSecurityIdService();
		return passList;
	}
	
	
	@GetMapping(path="/getForgotPass/{mypassNo}")
	@ResponseBody
	public ResponseEntity<ForgotPass> getAllSecurityId(@PathVariable("mypassNo") Integer passId) 
	{ 																		
		ForgotPass pass=null;
		
		pass = passwordServ.findSingleSecurityIdService(passId);
		if(pass==null)
		{ 
			return ResponseEntity.notFound().build();			
		}
		else
		{
			return ResponseEntity.ok(pass);
		}		
	}
}
