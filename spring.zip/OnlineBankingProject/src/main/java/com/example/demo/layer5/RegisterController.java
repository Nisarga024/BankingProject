package com.example.demo.layer5;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.layer2.Register;
import com.example.demo.layer2.RegisterDTO;
import com.example.demo.layer4.RegisterService;
import com.example.demo.layer4.exception.RegistrationAlreadyExistsException;
import com.example.demo.layer4.exception.RegistrationNotFoundException;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RegisterController 
{
	@Autowired
	RegisterService registerServ;
	

	@GetMapping(path="/getReg/{myreg}")
	@ResponseBody   //represents the whole HTTP response.
	public ResponseEntity<Register> getRegister(@PathVariable("myreg") Integer register) throws RegistrationNotFoundException
	{ 																	
		
		Register payee=null;
		
		payee = registerServ.findRegisterService(register);
		if(payee==null)
		{ 
			System.out.print("not found");
			return ResponseEntity.noContent().build();			
		}
		else
		{
			return ResponseEntity.ok(payee);
		}		
	}
	
	@GetMapping(path="/getRegs")
	@ResponseBody
	Set<Register>findRegistrationsService()
	{
		
		Set<Register> regSet = registerServ.findAllRegistrationService();
		return regSet;
		
	}

	@PostMapping(path="/addReg")
	public String addRegister(@RequestBody RegisterDTO register) throws RegistrationAlreadyExistsException
	{

		String stmsg = null;
		//Register reg = new Register();
		
		try 
		{
			stmsg = registerServ.addRegistrationService(register);
		} 
		catch (RegistrationAlreadyExistsException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 return stmsg;		
	}
}
