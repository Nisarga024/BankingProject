package com.example.demo.layer2;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;



@Entity
@Table(name="REGISTER")
@NamedQuery(name="Register.findAll", query="SELECT r FROM Register r")
public class Register  {
	//@GeneratedValue(strategy=GenerationType.AUTO)

	@Id
	@Column(name="REF_NO")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int refNo;

	@Column(name="AADHAR_NO")
	private String aadharNo;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String email;

	@Column(name="FATHERS_NAME")
	private String fathersName;

	private String fname;

	private String lname;

	private String mname;

	@Column(name="MOBILE_NO")
	private long mobileNo;

	private String occupation;

	@Column(name="PER_ADDRESS")
	private String perAddress;

	@Column(name="RES_ADDRESS")
	private String resAddress;

	//bi-directional many-to-one association to Customer
	@OneToMany(mappedBy="register", fetch=FetchType.EAGER)
	//@PrimaryKeyJoinColumn
	private Set<Customer> customers=new HashSet<Customer>(); //


	public Register() {
		super();
		System.out.println("Register Constructor()");
	}

	public int getRefNo() {
		return this.refNo;
	}

	public void setRefNo(int refNo) {
		this.refNo = refNo;
	}

	public String getAadharNo() {
		return this.aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFathersName() {
		return this.fathersName;
	}

	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public long getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getPerAddress() {
		return this.perAddress;
	}

	public void setPerAddress(String perAddress) {
		this.perAddress = perAddress;
	}

	public String getResAddress() {
		return this.resAddress;
	}

	public void setResAddress(String resAddress) {
		this.resAddress = resAddress;
	}

	public Set<Customer> getCustomers() {
		return this.customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

//	public Customer addCustomer(Customer customer) {
//		getCustomers().add(customer);
//		customer.setRegister(this);
//
//		return customer;
//	}
//
//	public Customer removeCustomer(Customer customer) {
//		getCustomers().remove(customer);
//		customer.setRegister(null);
//
//		return customer;
//	}

}