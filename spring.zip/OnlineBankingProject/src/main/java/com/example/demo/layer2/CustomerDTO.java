package com.example.demo.layer2;



import com.fasterxml.jackson.annotation.JsonIgnore;





public class CustomerDTO 
{
	
	private int custId;
	
	private long accNumber;

	private String accType;

	private String iniPassword;

	private long masterBal;

	private Register register;
	
	
	public CustomerDTO() {
		super();
		System.out.println("Customer constructor()");
	}

	public int getCustId() {
		return this.custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public long getAccNumber() {
		return this.accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccType() {
		return this.accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getIniPassword() {
		return this.iniPassword;
	}

	public void setIniPassword(String iniPassword) {
		this.iniPassword = iniPassword;
	}

	public long getMasterBal() {
		return this.masterBal;
	}

	public void setMasterBal(long masterBal) {
		this.masterBal = masterBal;
	}

	
	
	@JsonIgnore
	public Register getRegister() {
		return this.register;
	}

	public void setRegister(Register register) {
		this.register = register;
	}

	
//	public FundTransfer addFundtransfer(FundTransfer fundtransfer) {
//		getFundtransfers().add(fundtransfer);
//		fundtransfer.setCustomer(this);
//
//		return fundtransfer;
//	}
//
//	public FundTransfer removeFundtransfer(FundTransfer fundtransfer) {
//		getFundtransfers().remove(fundtransfer);
//		fundtransfer.setCustomer(null);
//
//		return fundtransfer;
//	}


//	public Payee addPayee(Payee payee) {
//		getPayees().add(payee);
//		payee.setCustomer(this);
//
//		return payee;
//	}
//
//	public Payee removePayee(Payee payee) {
//		getPayees().remove(payee);
//		payee.setCustomer(null);
//
//		return payee;
//	}

}