package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.ForgotPass;


@Repository
public class ForgotPassRepositoryImpl implements ForgotPassRepository
{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file


	@Transactional
	public ForgotPass findSingleSecurityId(int forgotNo)
	{
		System.out.println("Finding ForgotPassword..... ");
		return entityManager.find(ForgotPass.class,forgotNo);
	}
	   
	@Transactional
	public Set<ForgotPass> findAllSecurityId() 
	{
		List<ForgotPass> forgotList = new ArrayList<ForgotPass>();
		TypedQuery<ForgotPass> query = entityManager.createNamedQuery("ForgotPass.findAll",ForgotPass.class);
		forgotList =query.getResultList();
		Set<ForgotPass> forgotPassSet = new HashSet<ForgotPass>(forgotList );
		return forgotPassSet ;
	}	

	@Transactional
	public void removeForgotPasswordId(int forgotNo)
	{
		ForgotPass passTemp = entityManager.find(ForgotPass.class,forgotNo);
		entityManager.remove(passTemp);
	}
}
