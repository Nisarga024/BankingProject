package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.demo.layer2.ForgotPass;
import com.example.demo.layer3.ForgotPassRepository;


@SpringBootTest
public class ForgotPassRepoTesting {
	@Autowired
	ForgotPassRepository forgotPassRepo;

	@Test
	void deleteSecurityId()  // Delete Payee
    {
		forgotPassRepo.removeForgotPasswordId(17);
        System.out.println("....Removed Successfully!!.....");
    }
	
	@Test
	void findSingleSecurityQst()  //finding single payee By payeeID
	{  
		ForgotPass forgot = forgotPassRepo.findSingleSecurityId(11);	
		System.out.println("------------------------------");
		System.out.println("Security id  		 : "+forgot.getSecurityId());
		System.out.println("Security Questions  : "+forgot.getSecurityQst());
		System.out.println("------------------------------");
	}
	
	@Test
	void findAllSecurityQst()  //finding all Payee
	{
		Set<ForgotPass> securitySet = forgotPassRepo.findAllSecurityId();
		for(ForgotPass forgotId : securitySet)
		{
			System.out.println("............................... ");
			System.out.println("Security ID            : "+forgotId.getSecurityId());
			System.out.println("Security Question      : "+forgotId.getSecurityQst());
			System.out.println("............................... ");
		}
	}
	
}
