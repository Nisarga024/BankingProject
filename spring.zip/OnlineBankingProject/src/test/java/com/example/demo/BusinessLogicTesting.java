package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer2.Payee;
import com.example.demo.layer2.Register;

import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer3.ForgotPassRepository;
import com.example.demo.layer3.FundTransferRepository;
import com.example.demo.layer3.PayeeRepository;
import com.example.demo.layer3.RegisterRepository;

@SpringBootTest
class BusinessLogicTesting
{
	
	@Autowired
	RegisterRepository registerRepo;
	@Autowired
	PayeeRepository payeeRepo;
	@Autowired
	CustomerRepository customerRepo;
	@Autowired
	FundTransferRepository transferRepo;
	@Autowired
	ForgotPassRepository forgotRepo;
		
	@Test 
	void findCustomersbyServiceNo() 
	{ 
		  Set<Customer> custset = customerRepo.findCustomerbyServiceNo(3);
		  for (Customer customer: custset) 
		  { 
			 
			  	System.out.println("Customer ID    		: "+customer.getCustId());
				System.out.println("Account Type   		: "+customer.getAccType());
				System.out.println("Customer password   : "+customer.getIniPassword());
				System.out.println("Master Balance   	: "+customer.getMasterBal());
				System.out.println("Security ans   		: "+customer.getSecurityAns());
				System.out.println("Forgot pass id		: "+customer.getForgotPass().getSecurityId());
				System.out.println("Service number 		: "+customer.getRegister().getRefNo());
				System.out.println("-----------------"); 
	      }
	}
	
	@Test 
	void findPayeeByCustId() 
	{ 
		  Set<Payee> payset = payeeRepo.findPayeeByCustId(102);
		  for (Payee payee: payset) 
		  { 
			  	System.out.println("payee id 	:"+payee.getPayeeId());
				System.out.println("Account no  :"+payee.getBnefAccNo());
				System.out.println("bnef.Name   :"+payee.getBnefName());
				System.out.println("Nick name   :"+payee.getNickname());
				System.out.println("cust Id     :"+payee.getCustomer2().getCustId());	
				System.out.println("-----------------");
			 
		  }
	}
	
	@Test 
	void findTransfactionbyPayeeId() 
	{ 
		  Set<FundTransfer> fundset = transferRepo.findTransactionByPayeeId(202);
		  for (FundTransfer fundtransfer: fundset) 
		  { 
			  	
			  	System.out.println("trans id :"+fundtransfer.getTransactionId());
				System.out.println("amt      :"+fundtransfer.getAmountTrans());
				System.out.println("type     :"+fundtransfer.getTransactionType());
				System.out.println("date     :"+fundtransfer.getTransactionDate());
				System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
				System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
				System.out.println("-----------------");
			 
			 
	      }
	}
	@Test 
	void findTransfactionbyCustId() 
	{ 
		  Set<FundTransfer> fundset = transferRepo.findTransactionByCustId(104);
		  for (FundTransfer fundtransfer: fundset) 
		  { 
			  	
			  	System.out.println("trans id :"+fundtransfer.getTransactionId());
				System.out.println("amt      :"+fundtransfer.getAmountTrans());
				System.out.println("type     :"+fundtransfer.getTransactionType());
				System.out.println("date     :"+fundtransfer.getTransactionDate());
				System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
				System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
				System.out.println("-----------------");
			 
			 
	      }
	}

	@Test
	void searchingCustomerActivityFromRegistration()
	{ 							//finding reg-->cust-->payee-->fundtransfer
		Register register = registerRepo.findRegistration(4);
	
			System.out.println("service number: "+register.getRefNo());
			System.out.println(" F-Name       : "+register.getFname());
			System.out.println(" L-Name       : "+register.getLname());
			System.out.println(" M-Name       : "+register.getMname());
			System.out.println(" FATHER Name  : "+register.getFathersName());
			System.out.println(" Mobile number: "+register.getMobileNo());
			System.out.println(" Email        : "+register.getEmail());
			System.out.println(" Aadhar No    : "+register.getAadharNo());
			System.out.println(" DOB          : "+register.getDob());
			System.out.println(" Res-Address  : "+register.getResAddress());
			System.out.println(" Per-Address  : "+register.getPerAddress());
			System.out.println(" Occupation   : "+register.getOccupation());
			System.out.println("............................... ");
		
			Set<Customer>  custSet =register.getCustomers();	
			for (Customer customer : custSet) 
			{
				System.out.println("Customer ID    : "+customer.getCustId());
				System.out.println("Account Type   : "+customer.getAccType());
				System.out.println("Customer pass  : "+customer.getIniPassword());
				System.out.println("Customer Bal   : "+customer.getMasterBal());
				System.out.println("Security ans   : "+customer.getSecurityAns());
				System.out.println("Forgot pass id : "+customer.getForgotPass().getSecurityId());
				System.out.println("Service number : "+customer.getRegister().getRefNo());
				System.out.println("............................... ");
		
				Set<Payee> payeeSet = customer.getPayees();
				for (Payee payee : payeeSet)
				{
					System.out.println("payee id 	:"+payee.getPayeeId());
					System.out.println("Account no  :"+payee.getBnefAccNo());
					System.out.println("Name        :"+payee.getBnefName());
					System.out.println("Nick name   :"+payee.getNickname());
					System.out.println("cust id     :"+payee.getCustomer2().getCustId());	
					System.out.println("-----------------");
			
			
					Set<FundTransfer> fundSet = payee.getFundtransfers();
					for (FundTransfer fundtransfer : fundSet)
					{
						System.out.println("trans id :"+fundtransfer.getTransactionId());
						System.out.println("amt      :"+fundtransfer.getAmountTrans());
						System.out.println("type     :"+fundtransfer.getTransactionType());
						System.out.println("date     :"+fundtransfer.getTransactionDate());
						System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
						System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
						System.out.println("-----------------");
					}
				}
			}			
		}
	
	@Test
	void searchingCustomerActivity()
	{ 
		Customer customer= customerRepo.findCustomers(100);
		System.out.println("Customer ID    : "+customer.getCustId());
		System.out.println("Account Type   : "+customer.getAccType());
		System.out.println("Customer pass  : "+customer.getIniPassword());
		System.out.println("Customer Bal   : "+customer.getMasterBal());
		System.out.println("Security ans   : "+customer.getSecurityAns());
		System.out.println("Forgot pass id : "+customer.getForgotPass().getSecurityId());
		System.out.println("Service number : "+customer.getRegister().getRefNo());
		
		Set<Payee> payeeSet = customer.getPayees();
		for (Payee payee : payeeSet)
		{
			System.out.println("payee id 	:"+payee.getPayeeId());
			System.out.println("Account no  :"+payee.getBnefAccNo());
			System.out.println("Name        :"+payee.getBnefName());
			System.out.println("Nick name   :"+payee.getNickname());
			System.out.println("cust id     :"+payee.getCustomer2().getCustId());	
			System.out.println("-----------------");
	
	
			Set<FundTransfer> fundSet = payee.getFundtransfers();
			for (FundTransfer fundtransfer : fundSet)
			{
				System.out.println("trans id :"+fundtransfer.getTransactionId());
				System.out.println("amt      :"+fundtransfer.getAmountTrans());
				System.out.println("type     :"+fundtransfer.getTransactionType());
				System.out.println("date     :"+fundtransfer.getTransactionDate());
				System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
				System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
				System.out.println("-----------------");
			}
		}
	}
}