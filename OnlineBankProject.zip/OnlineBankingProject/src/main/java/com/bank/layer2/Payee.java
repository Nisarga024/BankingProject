package com.bank.layer2;




import javax.persistence.*;
import java.util.Set;

//@NamedQuery(name="Payee.findAll", query="SELECT p FROM Payee p")
@Entity
@Table(name="Payee")
public class Payee  {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PAYEE_ID")
	private int payeeId;

	@Column(name="BNEF_ACC_NO")
	private Double bnefAccNo;

	@Column(name="BNEF_NAME")
	private String bnefName;
	@Column(name="NICKNAME")
	private String nickname;

	//bi-directional many-to-one association to FundTransfer
	@OneToMany(mappedBy="payee", fetch=FetchType.EAGER)
	private Set<FundTransfer> fundTransfers;

	

	public Payee() {
		super();
		System.out.println("Payee Ctor");
	}

	public int getPayeeId() {
		return this.payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public Double getBnefAccNo() {
		return this.bnefAccNo;
	}

	public void setBnefAccNo(Double bnefAccNo) {
		this.bnefAccNo = bnefAccNo;
	}

	public String getBnefName() {
		return this.bnefName;
	}

	public void setBnefName(String bnefName) {
		this.bnefName = bnefName;
	}

	public String getNickname() {
		return this.nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Set<FundTransfer> getFundTransfers() {
		return this.fundTransfers;
	}

	public void setFundTransfers(Set<FundTransfer> fundTransfers) {
		this.fundTransfers = fundTransfers;
	}

	public FundTransfer addFundTransfer(FundTransfer fundTransfer) {
		getFundTransfers().add(fundTransfer);
		fundTransfer.setPayee(this);

		return fundTransfer;
	}

	public FundTransfer removeFundTransfer(FundTransfer fundTransfer) {
		getFundTransfers().remove(fundTransfer);
		fundTransfer.setPayee(null);

		return fundTransfer;
	}

	

}