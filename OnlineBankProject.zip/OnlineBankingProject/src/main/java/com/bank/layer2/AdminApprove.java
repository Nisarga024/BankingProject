package com.bank.layer2;


import javax.persistence.*;



/**
 * The persistent class for the ADMIN_APPROVE database table.
 * 
 */
@Entity
@Table(name="ADMIN_APPROVE")
//@NamedQuery(name="AdminApprove.findAll", query="SELECT a FROM AdminApprove a")
public class AdminApprove  {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CUST_ID")
	private int custId;

	@Column(name="ACC_NUMBER")
	private Double accNumber;

	@Column(name="ACC_TYPE")
	private String accType;

	@Column(name="INI_PASSWORD")
	private String iniPassword;

	@Column(name="MASTER_BAL")
	private Double masterBal;

	@Column(name="SECURITY_ANS")
	private String securityAns;

	//bi-directional many-to-one association to ForgotPass
	@OneToMany
	@JoinColumn(name="SECURITY_ID")
	private ForgotPass forgotPass;

	//bi-directional many-to-one association to Register
	@OneToOne
	@JoinColumn(name="REF_NO")
	private Register register;


	

	public AdminApprove() {
		super();
		System.out.println("AdminApprove Ctor");
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public Double getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(Double accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getIniPassword() {
		return iniPassword;
	}

	public void setIniPassword(String iniPassword) {
		this.iniPassword = iniPassword;
	}

	public Double getMasterBal() {
		return masterBal;
	}

	public void setMasterBal(Double masterBal) {
		this.masterBal = masterBal;
	}

	public String getSecurityAns() {
		return securityAns;
	}

	public void setSecurityAns(String securityAns) {
		this.securityAns = securityAns;
	}

	public ForgotPass getForgotPass() {
		return forgotPass;
	}

	public void setForgotPass(ForgotPass forgotPass) {
		this.forgotPass = forgotPass;
	}

	public Register getRegister() {
		return register;
	}

	public void setRegister(Register register) {
		this.register = register;
	}

	

	

}