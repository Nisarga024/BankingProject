package com.bank.layer2;


import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the FUND_TRANSFER database table.
 * @NamedQuery(name="FundTransfer.findAll", query="SELECT f FROM FundTransfer f")
 */
@Entity
@Table(name="FUND_TRANSFER")
public class FundTransfer  {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="TRANSACTION_ID")
	private int transactionId;

	@Column(name="AMOUNT_TRANS")
	private Double amountTrans;

	@Temporal(TemporalType.DATE)
	@Column(name="TRANSACTION_DATE")
	private Date transactionDate;

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	

	//bi-directional many-to-one association to Payee
	@ManyToOne
	@JoinColumn(name="PAYEE_ID")
	private Payee payee;

	public FundTransfer() {
		super();
		System.out.println("Fund transfer Ctor");
	}

	public int getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public Double getAmountTrans() {
		return this.amountTrans;
	}

	public void setAmountTrans(Double amountTrans) {
		this.amountTrans = amountTrans;
	}

	public Date getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}



	public Payee getPayee() {
		return this.payee;
	}

	public void setPayee(Payee payee) {
		this.payee = payee;
	}

}