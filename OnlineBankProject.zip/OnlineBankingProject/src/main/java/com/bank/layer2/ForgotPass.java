package com.bank.layer2;


import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the FORGOT_PASS database table.
 * 
 */
@Entity
@Table(name="FORGOT_PASS")
@NamedQuery(name="ForgotPass.findAll", query="SELECT f FROM ForgotPass f")
public class ForgotPass  {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SECURITY_ID")
	private int securityId;

	@Column(name="SECURITY_QST")
	private String securityQst;

	//bi-directional many-to-one association to AdminApprove
	@ManyToOne(cascade=CascadeType.ALL)
	private Set<AdminApprove> adminApproves;

	public ForgotPass() {
	}

	public int getSecurityId() {
		return this.securityId;
	}

	public void setSecurityId(int securityId) {
		this.securityId = securityId;
	}

	public String getSecurityQst() {
		return this.securityQst;
	}

	public void setSecurityQst(String securityQst) {
		this.securityQst = securityQst;
	}

	public Set<AdminApprove> getAdminApproves() {
		return this.adminApproves;
	}

	public void setAdminApproves(Set<AdminApprove> adminApproves) {
		this.adminApproves = adminApproves;
	}

	public AdminApprove addAdminApprove(AdminApprove adminApprove) {
		getAdminApproves().add(adminApprove);
		adminApprove.setForgotPass(this);

		return adminApprove;
	}

	public AdminApprove removeAdminApprove(AdminApprove adminApprove) {
		getAdminApproves().remove(adminApprove);
		adminApprove.setForgotPass(null);

		return adminApprove;
	}

}