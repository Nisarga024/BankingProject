package com.bank.layer2;


import javax.persistence.*;



import java.util.Date;
import java.util.HashSet;
import java.util.Set;
//@NamedQuery(name="Register.findAll", query="SELECT r FROM Register r")
@Entity
@Table(name="register")
public class Register  {
	@Id
	@GeneratedValue           //(strategy=GenerationType.AUTO)
	@Column(name="REF_NO")
	private int refNo;
	
	@Column(name="FNAME",length = 15)
	private String fname;
	
	@Column(name="MNAME",length = 10)
	private String mname;
	
	@Column(name="LNAME",length = 10)
	private String lname;
	
	@Column(name="FATHERS_NAME",length = 15)
	private String fathersName;
	
	@Column(name="MOBILE_NO")
	private int mobileNo;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="AADHAR_NO")
	private int aadharNo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DOB")
	private Date dob;
	
	@Column(name="RES_ADDRESS")
	private String resAddress;
	
	@Column(name="PER_ADDRESS")
	private String perAddress;
	
	@Column(name="OCCUPATION")
	private String occupation;

	//bi-directional many-to-one association to AdminApprove
	@OneToOne(mappedBy="register" ,cascade=CascadeType.ALL)
	private Set<AdminApprove> adminApproves = new HashSet<AdminApprove>();;

	public Register() {
		super();
		System.out.println("Register constructor is called");
	}

	public int getRefNo() {
		return refNo;
	}

	public void setRefNo(int refNo) {
		this.refNo = refNo;
	}

	public int getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFathersName() {
		return fathersName;
	}

	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getPerAddress() {
		return perAddress;
	}

	public void setPerAddress(String perAddress) {
		this.perAddress = perAddress;
	}

	public String getResAddress() {
		return resAddress;
	}

	public void setResAddress(String resAddress) {
		this.resAddress = resAddress;
	}

	public Set<AdminApprove> getAdminApproves() {
		return adminApproves;
	}

	public void setAdminApproves(Set<AdminApprove> adminApproves) {
		this.adminApproves = adminApproves;
	}

	

}