
package com.bank.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.layer2.FundTransfer;
import com.bank.layer4.FundTransferService;

@RestController
public class FundTransferController {
	@Autowired
	FundTransferService transferServ;
	
	@GetMapping(path="/getTrans")
	@ResponseBody
	public List<FundTransfer> getAllTransactions()
	{
		System.out.println("Transaction Controller....Understanding client and talking to service layer...");
		List<FundTransfer> transferList = transferServ.findTransactionsService();
		return transferList;
		
	}
	
	@PostMapping(path="/addTrans")
	public String addRegistration(@RequestBody FundTransfer transfer) {
		System.out.println("FundTransfer Controller....Understanding client and talking to service layer...");
		 String msg = null;
		try {
			msg = transferServ.addTransactionService(transfer);
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return msg;
		
	}
	@PutMapping(path="/modifyTrans")
	public String modifyTransaction(@RequestBody FundTransfer transfer) {
		String stsmsg = null;
		try {
			stsmsg =transferServ.modifyTransactionService(transfer);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return stsmsg;
	}
	@DeleteMapping(path="/deleteTrans")
	public String removeRegistration(@RequestBody FundTransfer transfer)
	{
		System.out.println("Transaction Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = transferServ.removeTransactionService(transfer.getTransactionId());
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
}