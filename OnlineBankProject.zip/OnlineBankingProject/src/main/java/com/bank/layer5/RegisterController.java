package com.bank.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.layer2.Register;
import com.bank.layer4.RegisterService;




@RestController  //REpresentational State Transfer html xml json
public class RegisterController {

	@Autowired
	RegisterService regServ;
	
	@GetMapping(path="/getRegs")
	@ResponseBody
	public List<Register> getAllRegistration()
	{
		System.out.println("Registration Controller....Understanding client and talking to service layer...");
		List<Register> regList = regServ.findRegistrationsService();
		return regList;
		
	}
	
	@PostMapping(path="/addReg")
	public String addRegistration(@RequestBody Register reg) {
		System.out.println("Register Controller....Understanding client and talking to service layer...");
		 String msg = null;
		try {
			msg = regServ.addRegistrationService(reg);
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return msg;
		
	}
	@DeleteMapping(path="/deleteRegs")
	public String removeRegistration(@RequestBody Register reg)
	{
		System.out.println("Register Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = regServ.removeRegistrationService(reg.getRefNo());
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
}
