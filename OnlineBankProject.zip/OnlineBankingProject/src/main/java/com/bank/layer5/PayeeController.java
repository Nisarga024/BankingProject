package com.bank.layer5;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.layer2.Payee;
import com.bank.layer4.PayeeService;
@RestController  //REpresentational State Transfer html xml json
public class PayeeController {

	@Autowired
	PayeeService payServ;
	
	@GetMapping(path="/getPayees")
	@ResponseBody
	public List<Payee> getAllPayee()
	{
		System.out.println("Payee Controller....Understanding client and talking to service layer...");
		List<Payee> payList = payServ.findPayeesService();
		return payList;
		
	}
	
	@PostMapping(path="/addPay")
	public String addPayee(@RequestBody Payee pay) {
		System.out.println("Payee Controller....Understanding client and talking to service layer...");
		 String msg = null;
		try {
			msg = payServ.addPayeeService(pay);
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return msg;
		
	}
	@DeleteMapping(path="/deletepays")
	public String removeRegistration(@RequestBody Payee pay)
	{
		System.out.println("Payee Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = payServ.removePayeeService(pay.getPayeeId());
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
}