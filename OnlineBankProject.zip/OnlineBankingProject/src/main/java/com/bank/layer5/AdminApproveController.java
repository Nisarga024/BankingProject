
package com.bank.layer5;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.layer2.AdminApprove;
import com.bank.layer4.AdminApproveService;
@RestController  //REpresentational State Transfer html xml json
public class AdminApproveController
{
	@Autowired
	AdminApproveService apprServ;
	
	@GetMapping(path="/getAppr")
	@ResponseBody
	public List<AdminApprove> getAllApprovals()
	{
		System.out.println("AdminApproveController....Understanding client and talking to service layer...");
		List<AdminApprove> apprList = apprServ.findApprovalsService();
		return apprList;
		
	}
	
}