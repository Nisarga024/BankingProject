package com.bank.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bank.layer2.Register;
@Service
public interface RegisterService {
	String addRegistrationService(Register rRef);  //C - add/create
	Register findRegistrationService(int rno);     //R - find/reading
	List<Register> findRegistrationsService();     //R - find all/reading all
	String removeRegistrationService(int rno); //D - remove/delete
	
}
