package com.bank.layer4;

public interface ForgotPassService {

}
