
package com.bank.layer4;
import java.util.List;
import org.springframework.stereotype.Service;
import com.bank.layer2.AdminApprove;
@Service
public interface AdminApproveService {
	
		List<AdminApprove> findApprovalsService();     //R  //R - find/reading	 - find all/reading all
		
		
	}