package com.bank.layer4;

public class ForgotPassServiceImpl {

}
