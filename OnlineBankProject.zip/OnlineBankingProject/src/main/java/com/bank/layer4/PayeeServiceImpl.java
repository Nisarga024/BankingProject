
package com.bank.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bank.layer2.Payee;
import com.bank.layer3.PayeeRepository;


public class PayeeServiceImpl implements PayeeService {

	@Autowired
	PayeeRepository payeeRepo;
	
	@Override
	public String addPayeeService(Payee PRef) {
		System.out.println("Payee Service....Some scope of bussiness logic here...");
			payeeRepo.addPayee(PRef);
		return "payee added successfully";
	}

	@Override
	public Payee findPayeeService(int pno) {
		System.out.println("Payee Service....Some scope of bussiness logic here...");
		return payeeRepo.findPayee(pno);
	}

	@Override
	public List<Payee> findPayeesService() {
		System.out.println("Payee Service....Some scope of bussiness logic here...");
		return payeeRepo.findPayees();
	}


	@Override
	public String removePayeeService(int pno) {
		Payee p =payeeRepo.findPayee(pno);
		payeeRepo.removePayee(p.getPayeeId());
		return "Payee Deleted successfully";
	}

}