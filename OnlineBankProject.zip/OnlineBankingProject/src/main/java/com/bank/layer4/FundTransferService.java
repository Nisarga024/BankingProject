
package com.bank.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bank.layer2.FundTransfer;

@Service
public interface FundTransferService {
	String addTransactionService(FundTransfer tRef);   //C - add/create
	FundTransfer findTransactionService(int tno);     //R - find/reading
	List<FundTransfer> findTransactionsService();       //R - find all/reading all
	String modifyTransactionService(FundTransfer tRef); 
	String removeTransactionService(int tno); //D - remove/delete
	
}