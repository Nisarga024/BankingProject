package com.bank.layer4;


import java.util.List;
import org.springframework.stereotype.Service;
import com.bank.layer2.Payee;

@Service
public interface PayeeService {
	String addPayeeService(Payee PRef);   
	Payee findPayeeService(int pno);     
	List<Payee> findPayeesService();    
	String removePayeeService(int pno); 
}