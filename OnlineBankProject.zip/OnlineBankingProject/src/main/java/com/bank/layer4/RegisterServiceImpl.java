package com.bank.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.layer2.Register;
import com.bank.layer3.RegisterRepository;

@Service
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	RegisterRepository regRepo;
	
	@Override
	public String addRegistrationService(Register rRef) 
	{
		System.out.println("Department Service....Some scope of bussiness logic here...");
		regRepo.addRegistration(rRef);
		return "Department added successfully";
	}
	
	@Override
	public Register findRegistrationService(int rno) 
	{
		System.out.println("Register Service....Some scope of bussiness logic here...");
		return regRepo.findRegistration(rno);
	}

	@Override
	public List<Register> findRegistrationsService() {
		System.out.println("Register Service....Some scope of bussiness logic here...");
		return regRepo.findRegistrations();
	}
	
	@Override
	public String removeRegistrationService(int rno)
	{
		Register r =regRepo.findRegistration(rno);
		regRepo.removeRegistration(r.getRefNo());
		return "Department Deleted successfully";
	}

}
