
package com.bank.layer4;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bank.layer2.AdminApprove;
import com.bank.layer3.AdminApproveRepository;

@Service
public class AdminApproveServiceImpl implements AdminApproveService {
	@Autowired
	AdminApproveRepository apprRepo;

	@Override
	public 	List<AdminApprove> findApprovalsService() {    
		System.out.println("AdminApprove Service....Some scope of bussiness logic here...");
		return apprRepo.findApprovals();
	}

	
}