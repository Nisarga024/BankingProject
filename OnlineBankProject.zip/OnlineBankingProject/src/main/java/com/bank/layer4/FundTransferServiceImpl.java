
package com.bank.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.layer2.FundTransfer;
import com.bank.layer3.FundTransferRepository;
@Service
public class FundTransferServiceImpl implements FundTransferService{
	
	@Autowired
	FundTransferRepository transferRepo;
	
	@Override
	public String addTransactionService(FundTransfer tRef) 
	{
		System.out.println("FundTransfer Service....Some scope of bussiness logic here...");
		transferRepo.addTransaction(tRef);
		return "Transaction added successfully";
	}
	
	@Override
	public FundTransfer findTransactionService(int tno) 
	{
		System.out.println("FundTransfer Service....Some scope of bussiness logic here...");
		return transferRepo.findTransaction(tno);
	}

	@Override
	public List<FundTransfer> findTransactionsService() {
		System.out.println("FundTransfer Service....Some scope of bussiness logic here...");
		return transferRepo.findTransactions();
	}
	@Override
	public String modifyTransactionService(FundTransfer tRef) 
	{
		System.out.println("FundTransfer Service....Some scope of bussiness logic here...");
		transferRepo.modifyTransaction(tRef);
		return "Transaction modified successfully";
	}
	
	@Override
	public String removeTransactionService(int tno)
	{
		FundTransfer t =transferRepo.findTransaction(tno);
		transferRepo.removeTransaction(t.getTransactionId());
		return "Transaction Deleted successfully";
	}

}