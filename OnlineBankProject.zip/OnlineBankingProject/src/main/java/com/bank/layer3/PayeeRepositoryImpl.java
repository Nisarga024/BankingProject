
package com.bank.layer3;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bank.layer2.Payee;


@Repository
public class PayeeRepositoryImpl implements PayeeRepository {
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addPayee(Payee PRef) {//usesA
		entityManager.persist(PRef);

	}
	
	@Transactional
	public Payee findPayee(int pno) {//producesA Department obj
		System.out.println("Payee repo....NO scope of bussiness logic here...");
		return entityManager.find(Payee.class,pno);
		
	}
	@Transactional
	public void removePayee(int pno) {
		Payee pTemp = entityManager.find(Payee.class,pno);
		entityManager.remove(pTemp);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Payee> findPayees() {
		List<Payee> payeeList;
		payeeList = new ArrayList<Payee>();
		
			String queryString = "from payee";
			Query query = entityManager.createQuery(queryString);
			payeeList = query.getResultList();
			return payeeList;
		}

}