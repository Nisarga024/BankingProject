
package com.bank.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.bank.layer2.FundTransfer;
@Repository
public class FundTransferRepositoryImpl implements FundTransferRepository {
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
										
	
	@Transactional//no need of begin transaction and commit rollback
	public void  addTransaction(FundTransfer tRef) //usesA
	{
		entityManager.persist(tRef);
	}
	
	@Transactional
	public FundTransfer findTransaction(int tno)//producesA transaction obj
	{
		System.out.println("Transaction repo....NO scope of bussiness logic here...");
		return entityManager.find(FundTransfer.class,tno);
		
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<FundTransfer> findTransactions()
	{
		List<FundTransfer> TransferList = new ArrayList<FundTransfer>();
		String queryString = "from fund_transfer";
		Query query = entityManager.createQuery(queryString);
		TransferList = query.getResultList();
		return TransferList;
		
		
	}
	@Transactional
	public void modifyTransaction(FundTransfer tRef) {
		entityManager.merge(tRef);
		
	}
	@Transactional
	public void removeTransaction(int tno) {
		FundTransfer dTemp = entityManager.find(FundTransfer.class,tno);
		entityManager.remove(dTemp);
		
	}
}