package com.bank.layer3;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.bank.layer2.Register;




@Repository
public interface RegisterRepository {
	void addRegistration(Register rRef);   //C - add/create
	Register findRegistration(int rno);     //R - find/reading
	List<Register> findRegistrations();     //R - find all/reading all
	void removeRegistration(int rno); //D - remove/delete
	Set<Register>  findRegistrations(int rno);  
}
