package com.bank.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bank.layer2.Register;




@Repository
public class RegisterRepositoryImpl implements RegisterRepository{

	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void  addRegistration(Register rRef) {//usesA
		entityManager.persist(rRef);

	}
	@Transactional
	public Register findRegistration(int rno) {//producesA Registration obj
		System.out.println("Registration repo....NO scope of bussiness logic here...");
		return entityManager.find(Register.class,rno);
		
	}
	
	
	@Override
	public Set<Register> findRegistrations(int rno) {
		
		Set<Register> regSet;
		Query query = entityManager.createQuery("from register",Register.class).setParameter("refNo", rno);
			//empSet = (Set<Employee2>) query.getResultList().stream().collect(Collectors.toSet());
			
			regSet = new HashSet(query.getResultList());
			return regSet;
	
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Register> findRegistrations() {
		List<Register> regList;
		regList = new ArrayList<Register>();
		
			String queryString = "from register";
			Query query = entityManager.createQuery(queryString);
			regList = query.getResultList();
				return regList;
		
		
	}
	@Transactional
	public void removeRegistration(int rno) {
		Register dTemp = entityManager.find(Register.class,rno);
		entityManager.remove(dTemp);
		
	}
}
