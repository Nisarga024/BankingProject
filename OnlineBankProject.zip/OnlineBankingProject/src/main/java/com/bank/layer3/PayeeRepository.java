
package com.bank.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bank.layer2.Payee;

@Repository
public interface PayeeRepository
{
	void addPayee(Payee PRef);   //C - add/create
	Payee findPayee(int pno);     //R - find/reading
	List<Payee> findPayees();     //R - find all/reading all
	void removePayee(int pno); //D - remove/delete
}