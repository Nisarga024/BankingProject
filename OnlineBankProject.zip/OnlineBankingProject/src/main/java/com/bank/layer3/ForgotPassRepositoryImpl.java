package com.bank.layer3;

public class ForgotPassRepositoryImpl implements ForgotPassRepository {

}
