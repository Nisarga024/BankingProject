
package com.bank.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bank.layer2.FundTransfer;
@Repository
public interface FundTransferRepository 
{
	void addTransaction(FundTransfer tRef);   // add/create
	FundTransfer findTransaction(int tno);     
	List<FundTransfer> findTransactions();
	void modifyTransaction(FundTransfer tRef); //find all/reading all
	void removeTransaction(int tno); //remove/delete
	 
}