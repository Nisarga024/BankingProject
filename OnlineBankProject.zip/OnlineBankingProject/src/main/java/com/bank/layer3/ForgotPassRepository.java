package com.bank.layer3;

public interface ForgotPassRepository {

}
