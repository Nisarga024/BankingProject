
package com.bank.layer3;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.bank.layer2.AdminApprove;

@Repository
public class AdminApproveRepositoryImpl implements AdminApproveRepository{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
       

	@SuppressWarnings("unchecked")
	@Transactional
	public List<AdminApprove> findApprovals() 
	{
			List<AdminApprove> apprList = new ArrayList<AdminApprove>();
			String queryString = "from admin_approve";
			Query query = entityManager.createQuery(queryString);
			apprList = query.getResultList();
			return apprList;		
	}

}