package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bank.layer2.Register;
import com.bank.layer3.RegisterRepository;



@SpringBootTest
class OnlineBankingProjectApplicationTests {
	@Autowired
	RegisterRepository regRepo;
	@Test
	
	void contextLoads() {
		Set<Register> regSet = regRepo.findRegistrations(12345);
		for (Register r: regSet) {
			System.out.println(r.getRefNo());
			System.out.println(r.getFname());
			System.out.println(r.getLname());
			System.out.println(r.getMname());
			System.out.println(r.getFathersName());
			System.out.println(r.getMobileNo());
			System.out.println(r.getEmail());
			System.out.println(r.getAadharNo());
			System.out.println(r.getDob());
			System.out.println(r.getResAddress());
			System.out.println(r.getPerAddress());
			System.out.println(r.getOccupation());
			System.out.println("-----------------");
		}
}
}