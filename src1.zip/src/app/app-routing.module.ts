import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';

import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PayeeComponent } from './payee/payee.component';

import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  // {path:'',component:NavbarComponent},
  {path :'home',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component: LoginComponent,
  children:
  [{ path:'forgotpassword',component:ForgotPasswordComponent}]},
  {path:'aboutus',component: AboutUsComponent},
  {path:'forgotpassword',component:ForgotPasswordComponent},
  {path: '', redirectTo:'home', pathMatch:'full'},
  {path:'dashboard',component:DashboardComponent,
    children:
    [      {path:'fund-transfer',component:FundTransferComponent},
            {path:'accountstatement',component:AccountStatementComponent},
            {path:'payee',component:PayeeComponent},
            {path:'accountdetails',component:AccountStatementComponent}
    ]},
  {path:'dashboard',component:DashboardComponent},
  {path:'fundtransfer',component:FundTransferComponent},
  {path:'accountstatement',component:AccountStatementComponent},
  {path:'payee',component:PayeeComponent},
  {path:'accountdetails',component:AccountDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
