import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  newPayeeClicked =false;

  payees=[
    { id: 201 ,name:"Sravani",accountno:287478 ,nickname:"sravani",custid:100  }
  ];
  color:any;
  constructor() { }

  ngOnInit(): void {
  }
  model:any ={};
model2:any={};
addPayee(){
  this.payees.push(this.model);
  this.model={}
}
deletePayee(i:any){
  this.payees.splice(i);
console.log(i);
}
myValue:any;

UpdatePayee(){
  let editPayeeInfo=this.myValue;
  for(let i=0;i<this.payees.length;i++)
  {
    if(i==editPayeeInfo){
      this.payees[i]=this.model2;
      this.model2={}
    }
  }
}
addNewPayeeBtn(){
this.newPayeeClicked=!this.newPayeeClicked;

}

  
changeColorOne(){
  this.color =!this.color;
  if(this.color){
    return '#ffffff';
  }else{
    return '#f6f6f6';
  }
}

}
