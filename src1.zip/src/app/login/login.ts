export class login {
    custid: string
    password: string

    constructor() {
        this.custid = ''
        this.password = ''
    }

    getUsername(): string{
        return this.custid;
    }

    getPassword(): string{
        return this.password;
    }
}