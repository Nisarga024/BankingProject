package com.example.demo.layer4;


import java.util.Set;

import org.springframework.stereotype.Service;


import com.example.demo.layer2.Register;
import com.example.demo.layer4.exception.RegistrationAlreadyExistsException;
import com.example.demo.layer4.exception.RegistrationNotFoundException;

@Service
public interface RegisterService 
{
	String addRegistrationService(Register registerRef) throws RegistrationAlreadyExistsException;   
	Register findRegisterService(int regNo) throws RegistrationNotFoundException;
	Set<Register>findAllRegistrationService();    //All registration service
	
}
