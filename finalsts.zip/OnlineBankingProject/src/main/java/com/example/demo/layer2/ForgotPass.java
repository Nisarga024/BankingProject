package com.example.demo.layer2;


import javax.persistence.*;
import java.util.Set;



@Entity
@Table(name="FORGOTPASS")
@NamedQuery(name="ForgotPass.findAll", query="SELECT f FROM ForgotPass f")
public class ForgotPass {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SECURITY_ID")
	private int securityId;

	@Column(name="SECURITY_QST")
	private String securityQst;

	//bi-directional many-to-one association to Customer
	@OneToMany(mappedBy="forgotpass", fetch=FetchType.EAGER)
	//@PrimaryKeyJoinColumn
	private Set<Customer> customers;

	public ForgotPass() 
	{
		super();
		System.out.println("ForgotPassword constructor()");
	}

	public int getSecurityId() {
		return this.securityId;
	}

	public void setSecurityId(int securityId) {
		this.securityId = securityId;
	}

	public String getSecurityQst() {
		return this.securityQst;
	}

	public void setSecurityQst(String securityQst) {
		this.securityQst = securityQst;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	
//	public Customer addCustomer(Customer customer) {
//		getCustomers().add(customer);
//		customer.setForgotPass(this);
//
//		return customer;
//	}
//
//	public Customer removeCustomer(Customer customer) {
//		getCustomers().remove(customer);
//		customer.setForgotPass(null);
//
//		return customer;
//	}

}