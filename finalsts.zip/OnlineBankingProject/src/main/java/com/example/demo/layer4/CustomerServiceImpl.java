package com.example.demo.layer4;


import java.util.Set;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.layer2.Customer;
import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;


@Service
public class CustomerServiceImpl implements CustomerService 
{
	@Autowired
	CustomerRepository customerRepo;
	
	@Override
	public String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException
	{
			try 
			{
				customerRepo.addCustomer(custRef);
			} 
			catch (Exception e)
			{
//				e.printStackTrace();
//				throw e;
				throw new CustomerAlreadyExistsException("Customer already exists");
			}
			System.out.println("Customer added successfully");
			return "Customer added successfully";
	}

	@Override
	public Customer findCustomerService(int custNo)throws CustomerNotFoundException 
	{		
		try 
		{
			return customerRepo.findCustomers(custNo);
		} 
		catch (Exception e)
		{
			throw new CustomerNotFoundException("Customer not found");	
		}
	}

	@Override
	public Set<Customer> findAllCustomersService()
	{	
		return customerRepo.findAllCustomers();
	}

	
	@Override
	public Set<Customer> findCustomerbyServiceNo(int serviceNo)
	{
		Set<Customer>custSet=customerRepo.findCustomerbyServiceNo(serviceNo);
		return custSet;
	}
	

//	@Override
//	public Customer findCustomerService(int custNo) throws CustomerNotFoundException{
//		
//	 try {
//		customerRepo.findCustomers(custNo);
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		//e.printStackTrace();	
//		throw new CustomerNotFoundException("Customer doesn't exists");
//	}
//	 System.out.println("Customer found successfully");
//		//return "Customer found successfully";
//	
//	}

}
