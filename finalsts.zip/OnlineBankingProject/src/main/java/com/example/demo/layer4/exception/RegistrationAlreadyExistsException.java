package com.example.demo.layer4.exception;


@SuppressWarnings("serial")
public class RegistrationAlreadyExistsException extends Throwable
{
	
	public RegistrationAlreadyExistsException(String msg)
	{
		super(msg);
	}

}



