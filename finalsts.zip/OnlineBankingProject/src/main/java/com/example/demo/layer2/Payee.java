package com.example.demo.layer2;



import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the PAYEE database table.
 * 
 */
@Entity
@Table(name="PAYEE")
@NamedQuery(name="Payee.findAll", query="SELECT p FROM Payee p")
public class Payee {
	

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PAYEE_ID")
	private int payeeId;

	@Column(name="BNEF_ACC_NO")
	private long bnefAccNo;

	@Column(name="BNEF_NAME")
	private String bnefName;

	private String nickname;
	
	@ManyToOne
	@JoinColumn(name="CUST_ID")
	private Customer customer2;

	//bi-directional many-to-one association to Fundtransfer
	@OneToMany(mappedBy="payee", fetch=FetchType.EAGER)
	private Set<FundTransfer> fundtransfers;

	//bi-directional many-to-one association to Customer
	

	public Payee() {
		super();
		System.out.println("Payee constructor()");
	}

	public int getPayeeId() {
		return this.payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public long getBnefAccNo() {
		return this.bnefAccNo;
	}

	public void setBnefAccNo(long bnefAccNo) {
		this.bnefAccNo = bnefAccNo;
	}

	public String getBnefName() {
		return this.bnefName;
	}

	public void setBnefName(String bnefName) {
		this.bnefName = bnefName;
	}

	public String getNickname() {
		return this.nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Set<FundTransfer> getFundtransfers() {
		return fundtransfers;
	}

	public void setFundtransfers(Set<FundTransfer> fundtransfers) {
		this.fundtransfers = fundtransfers;
	}
	@JsonIgnore
	public Customer getCustomer2() {
		return this.customer2;
	}

	public void setCustomer2(Customer customer) {
		this.customer2 = customer;
	}


//	public FundTransfer addFundTransfer(FundTransfer fundtransfer) {
//		getFundtransfers().add(fundtransfer);
//		fundtransfer.setPayee(this);
//
//		return fundtransfer;
//	}
//
//	public FundTransfer removeFundTransfer(FundTransfer fundtransfer) {
//		getFundtransfers().remove(fundtransfer);
//		fundtransfer.setPayee(null);
//
//		return fundtransfer;
//	}


}