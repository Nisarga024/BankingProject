package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.layer2.Register;
import com.example.demo.layer3.RegisterRepository;
import com.example.demo.layer4.exception.RegistrationAlreadyExistsException;
import com.example.demo.layer4.exception.RegistrationNotFoundException;

@Service
public class RegisterServiceImpl implements RegisterService
{

	@Autowired
	RegisterRepository registerRepo;
	
	@Override
	public String addRegistrationService(Register registerRef)  throws RegistrationAlreadyExistsException
	{
		try 
		{
			registerRepo.addRegistration(registerRef);			
		} 
		catch (Exception e) 
		{				
//			e.printStackTrace();
//			throw e;
			throw new RegistrationAlreadyExistsException("Registration already exists");
		}
		System.out.println("Register added successfully");
		return "Registration added successfully";
	}

		
	@Override
	public Set<Register> findAllRegistrationService() 
	{
		return registerRepo.findRegistration();
	}

	@Override
	public Register findRegisterService(int regNo) throws RegistrationNotFoundException
	{ 			
		try 
		{
			return registerRepo.findRegistration(regNo);
		} 
		catch (Exception e) 
		{
			throw new RegistrationNotFoundException("Registration not found");	
		}
	}
		
	

}
