package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class CustomerNotFoundException extends Exception
{
	public CustomerNotFoundException(String msg) 
	{
		super(msg);
	}
}
