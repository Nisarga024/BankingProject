package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.ForgotPass;

@Service
public interface ForgotPassService 
{
	ForgotPass findSingleSecurityIdService(int forgotNo);
	Set<ForgotPass> findAllSecurityIdService();
	String removeForgotPasswordIdService(int forgotNo); 
}
