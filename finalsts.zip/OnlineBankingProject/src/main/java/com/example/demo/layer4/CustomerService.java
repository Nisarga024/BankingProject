package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;


@Service
public interface CustomerService 
{
	String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException;
	Customer findCustomerService(int custNo)throws CustomerNotFoundException ;
	Set<Customer>findAllCustomersService(); 	
Set<Customer> findCustomerbyServiceNo(int serviceNo);

}