package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer3.FundTransferRepository;
import com.example.demo.layer4.exception.FundTransferAlreadyExistsException;
import com.example.demo.layer4.exception.FundTransferNotFoundException;
@Service
public class FundTransferServiceImpl implements FundTransferService
{
	@Autowired
	FundTransferRepository transferRepo;
	
	@Override
	public String addTransactionService(FundTransfer fundtransRef) throws FundTransferAlreadyExistsException 
	{								
		try 
		{
			transferRepo.addTransaction(fundtransRef);
		} 
		catch (Exception e) 
		{	
//			e.printStackTrace();
//			throw e ; //
			throw new FundTransferAlreadyExistsException("Transaction Id already exists");
		}
		System.out.println("Transaction added successfully");
		return "Transaction added successfully";
		
	}

	@Override
	public FundTransfer findTransactionsService(int fundNo)throws FundTransferNotFoundException
	{ 	
		try {
			return transferRepo.findTransaction(fundNo);
		}
		catch (Exception e)
		{
			throw new FundTransferNotFoundException("Transaction ID not found");	
		}
				
	}

	@Override
	public Set<FundTransfer> findAllTransactionsService()
	{		
		return transferRepo.findAllTransactions();
	}



	
	@Override
	public Set<FundTransfer> findTransactionByCustId(int custId)
	{
		Set<FundTransfer>fundSet=transferRepo.findTransactionByCustId(custId);
		return fundSet;
	}
	
	@Override
	public Set<FundTransfer> findTransactionByPayeeId(int payeeId)
	{
		Set<FundTransfer>fundSet=transferRepo.findTransactionByPayeeId(payeeId);
		return fundSet;
	}
}
