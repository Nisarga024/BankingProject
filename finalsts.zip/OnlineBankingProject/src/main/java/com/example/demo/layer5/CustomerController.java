package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Customer;

import com.example.demo.layer4.CustomerService;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;


@RestController
public class CustomerController 
{
	@Autowired
	CustomerService customerServ;
	
	@GetMapping(path="/getCust/{mycust}")
	@ResponseBody
	public ResponseEntity<Customer> getCustomer(@PathVariable("mycust") Integer customer) throws CustomerNotFoundException
	{ 																		
		Customer cust=null;
		
		cust = customerServ.findCustomerService(customer);
		if(cust==null)
		{ 
			return ResponseEntity.notFound().build();			
		}
		else
		{
			return ResponseEntity.ok(cust);
		}		
	}
	
	@GetMapping(path="/getCusts")
	@ResponseBody
	Set<Customer>findAllCustomerService()
	{		
		Set<Customer> custSet =customerServ.findAllCustomersService();
		return custSet;		
	}
	
	@PostMapping(path="/addCust")
	public String addCustomer(@RequestBody Customer cust) throws CustomerAlreadyExistsException
	{	
		String stmsg = null;
		try 
		{
			stmsg = customerServ.addCustomerService(cust);
		} 
		catch (CustomerAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 return stmsg;		
	}
	@GetMapping(path="/getcust/{myserviceNo}")
	@ResponseBody
	public Set<Customer> getCustController(@PathVariable("myserviceNo") int serviceNo) {
		Set<Customer> custSet=customerServ.findCustomerbyServiceNo(serviceNo);
		return custSet;
	}
}
