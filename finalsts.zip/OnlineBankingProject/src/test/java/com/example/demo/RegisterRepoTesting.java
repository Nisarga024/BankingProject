package com.example.demo;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Register;
import com.example.demo.layer3.RegisterRepository;

@SpringBootTest
public class RegisterRepoTesting {
	@Autowired
	RegisterRepository registerRepo;
	
	@Test
	void addRegistration()    //adding register
	{ 
			Register register = new Register();
			
			register.setRefNo(1);
			register.setFname("NAVEEN");			
			register.setMname("");
			register.setLname("LAGADAPATI");
			register.setFathersName("Mr.Ganesh");
			register.setMobileNo(923146754);
			register.setEmail("naveen@gmail.com");		
			register.setAadharNo("4534564599");
			
			String str="1998-02-30";
			Date date=Date.valueOf(str);
			register.setDob(date);
			
			register.setResAddress("AndraPradesh");
			register.setPerAddress("AndraPradesh");
			register.setOccupation("Business");
			System.out.println("-----------------");
			registerRepo.addRegistration(register);
			System.out.println("....Registration Added!!.....");
	}

	@Test
	void getSingleRegistration()   //finding single registration By ServiceRefNo
	{
	
		Register register = registerRepo.findRegistration(4);
		System.out.println("............................... ");
		System.out.println("Service Ref.No : "+register.getRefNo());
		System.out.println(" F-Name        : "+register.getFname());
		System.out.println(" L-Name        : "+register.getLname());
		System.out.println(" M-Name        : "+register.getMname());
		System.out.println(" FATHER Name   : "+register.getFathersName());
		System.out.println(" Mobile number : "+register.getMobileNo());
		System.out.println(" Email         : "+register.getEmail());
		System.out.println(" Aadhar No     : "+register.getAadharNo());
		System.out.println(" DOB           : "+register.getDob());
		System.out.println(" Res-Address   : "+register.getResAddress());
		System.out.println(" Per-Address   : "+register.getPerAddress());
		System.out.println(" Occupation    : "+register.getOccupation());
		System.out.println("............................... ");
	}

	@Test
	void findallRegistration()   //finding all Registration
	{
		Set<Register> registerSet = registerRepo.findRegistration();
		for(Register register :registerSet) 
		{
			System.out.println("------------------------------");
			System.out.println("service number: "+register.getRefNo());
			System.out.println(" F-Name       : "+register.getFname());
			System.out.println(" L-Name       : "+register.getLname());
			System.out.println(" M-Name       : "+register.getMname());
			System.out.println(" FATHER Name  : "+register.getFathersName());
			System.out.println(" Mobile number: "+register.getMobileNo());
			System.out.println(" Email        : "+register.getEmail());
			System.out.println(" Aadhar No    : "+register.getAadharNo());
			System.out.println(" DOB          : "+register.getDob());
			System.out.println(" Res-Address  : "+register.getResAddress());
			System.out.println(" Per-Address  : "+register.getPerAddress());
			System.out.println(" Occupation   : "+register.getOccupation());
			System.out.println("............................... ");
		}
	}
}
