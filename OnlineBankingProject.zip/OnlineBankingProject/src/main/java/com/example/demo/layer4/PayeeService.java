package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Payee;
import com.example.demo.layer4.exception.PayeeAlreadyExistsException;

@Service
public interface PayeeService 
{
	String addPayeeService(Payee payeeRef)throws PayeeAlreadyExistsException;   //C - add/create
	Payee findPayeeService(int payeeNo); // throws PayeeNotFoundException; 
	//Set<Payee> findPayeesService(int payeeNo);
	Set<Payee>findAllPayeesService(); //R - find/reading   //R - find all/reading all
	String removePayeeService(int payeeNo); // throws PayeeNotFoundException; //D - remove/delete
	
}