package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class RegistrationNotFoundException extends Throwable{
	public RegistrationNotFoundException(String msg) {
		super(msg);
	}
}




