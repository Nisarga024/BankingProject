package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;


@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepo;
	@Override
	public String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException {
	
			try {
				customerRepo.addCustomer(custRef);
			} 
			catch (Exception e)
			{
				// TODO Auto-generated catch block
//				e.printStackTrace();
//				throw e;
				throw new CustomerAlreadyExistsException("Customer already exists");
			}
			System.out.println("Customer added successfully");
			return "Customer added successfully";
	}

	@Override
	public Customer findCustomerService(int custNo) {
		
		return customerRepo.findCustomers(custNo);
	}

	@Override
	public Set<Customer> findAllCustomersService() {
	
		return customerRepo.findAllCustomers();
	}

}
