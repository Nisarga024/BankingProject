
package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.Customer;


@Repository
public class CustomerRepositoryImpl implements CustomerRepository{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
       

	@Transactional
	public void addCustomer(Customer customerRef)
	{
		entityManager.persist(customerRef);		
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Customer> findCustomer(int customerNo) 
	{
		Set<Customer> custSet;
		
		Query query = entityManager.createQuery("from Customers",Customer.class).setParameter("custId", customerNo);
		custSet = new HashSet(query.getResultList());
		return custSet;		
	}


	@Override
	public Customer findCustomers(int customerNo) 
	{
		System.out.println("Customers repo....NO scope of bussiness logic here...");
		return entityManager.find(Customer.class,customerNo);
	}
	
	@Override
	public Set<Customer> findAllCustomers()
	{
		List<Customer> custlist = new ArrayList<Customer>();
		TypedQuery<Customer> query = entityManager.createNamedQuery("Customer.findAll",Customer.class);
		custlist=query.getResultList();
		Set<Customer> custSet = new HashSet<Customer>(custlist);
		return custSet;
	}
}