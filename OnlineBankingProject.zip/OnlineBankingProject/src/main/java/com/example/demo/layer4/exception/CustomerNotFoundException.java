package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class CustomerNotFoundException extends Throwable{
	public CustomerNotFoundException(String msg) {
		super(msg);
	}

}
