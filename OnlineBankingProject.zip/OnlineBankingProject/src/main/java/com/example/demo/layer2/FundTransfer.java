package com.example.demo.layer2;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;


@Entity
@Table(name="FUNDTRANSFER")
@NamedQuery(name="FundTransfer.findAll", query="SELECT f FROM FundTransfer f")
public class FundTransfer  {
	//@GeneratedValue(strategy=GenerationType.AUTO)

	@Id
	@Column(name="TRANSACTION_ID")
	private int transactionId;

	@Column(name="AMOUNT_TRANS")
	private long amountTrans;

	@Temporal(TemporalType.DATE)
	@Column(name="TRANSACTION_DATE")
	private Date transactionDate;

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="CUST_ID")
	private Customer customer1;

	//bi-directional many-to-one association to Payee
	@ManyToOne
	@JoinColumn(name="PAYEE_ID")
	private Payee payee;

	public FundTransfer() {
		super();
		System.out.println("FundTransfer constructor()");
	}

	public int getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public long getAmountTrans() {
		return this.amountTrans;
	}

	public void setAmountTrans(long amountTrans) {
		this.amountTrans = amountTrans;
	}

	public Date getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	@JsonIgnore
	public Customer getCustomer1() {
		return this.customer1;
	}

	public void setCustomer1(Customer customer) {
		this.customer1 = customer;
	}
	@JsonIgnore
	public Payee getPayee() {
		return this.payee;
	}

	public void setPayee(Payee payee) {
		this.payee = payee;
	}

}