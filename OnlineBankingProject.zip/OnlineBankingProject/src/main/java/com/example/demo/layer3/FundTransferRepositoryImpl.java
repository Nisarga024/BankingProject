
package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.FundTransfer;




@Repository
public class FundTransferRepositoryImpl implements FundTransferRepository {
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
										
	
	@Transactional//no need of begin transaction and commit rollback
	public void  addTransaction(FundTransfer fundtransferRef) //usesA
	{
		entityManager.persist(fundtransferRef);
	}
	
	@Transactional
	public FundTransfer findTransaction(int fundNo)//producesA transaction obj
	{
		System.out.println("Transaction repo....NO scope of bussiness logic here...");
		return entityManager.find(FundTransfer.class,fundNo);
		
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<FundTransfer> findTransactions(int fundNo)
	{
		Set<FundTransfer> fundSet;
		Query query = entityManager.createQuery("from fundtransfer",FundTransfer.class).setParameter("transactionId", fundNo);	
		fundSet = new HashSet(query.getResultList());
		return fundSet;		
	}

	@Override
	public Set<FundTransfer> findAllTransactions() {
		List<FundTransfer> fundlist = new ArrayList<FundTransfer>();
		TypedQuery<FundTransfer> query = entityManager.createNamedQuery("FundTransfer.findAll",FundTransfer.class);
		fundlist=query.getResultList();
		Set<FundTransfer> rSet = new HashSet<FundTransfer>(fundlist);
		return rSet;
	}

	@Transactional
	public void removeTransaction(int fundNo) {
		FundTransfer fundTemp = entityManager.find(FundTransfer.class,fundNo);
		entityManager.remove(fundTemp);
		
	}
	
	
	
}