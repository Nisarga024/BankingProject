package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Register;

@Repository
public class RegisterRepositoryImpl implements RegisterRepository
{

	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional		//no need of begin transaction and commit rollback
	public void  addRegistration(Register registerRef) 
	{												//usesA
		entityManager.persist(registerRef);
	}
	
	@Transactional
	public Register findRegistration(int register)
	{											//producesA Registration obj
		System.out.println("Registration repo....NO scope of bussiness logic here...");
		return entityManager.find(Register.class,register);
		
	}
	//@Override
	
	@Transactional
	public Set<Register> findRegistration() 
	{
	
		List<Register> list = new ArrayList<Register>();
		TypedQuery<Register> query = entityManager.createNamedQuery("Register.findAll",Register.class);
		list=query.getResultList();
		Set<Register> rSet = new HashSet<Register>(list);
		return rSet;
	}
	
	//@Override
	
	@Transactional
	public Set<Register> findRegistrations(int register)
	{		
		Set<Register> registerSet;
		Query query = entityManager.createQuery("from register",Register.class).setParameter("refNo", register);	
		registerSet = new HashSet(query.getResultList());
		return registerSet;	
	}
		
}
