package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;


import com.example.demo.layer2.Register;

@Repository
public interface RegisterRepository
{
	void addRegistration(Register registerRef);   
	Set<Register>findRegistration();    
	Set<Register>findRegistrations(int register); 
	Register findRegistration(int register);
	
}
