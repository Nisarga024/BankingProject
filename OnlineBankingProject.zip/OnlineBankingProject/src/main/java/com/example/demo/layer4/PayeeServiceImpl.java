package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Payee;
import com.example.demo.layer3.PayeeRepository;

import com.example.demo.layer4.exception.PayeeAlreadyExistsException;

@Service
public class PayeeServiceImpl implements PayeeService
{
	@Autowired
	PayeeRepository payeeRepo;

	@Override
	public String addPayeeService(Payee payeeRef)  throws PayeeAlreadyExistsException
	{			 
		     
		try 
		{
			payeeRepo.addPayee(payeeRef);
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
//			e.printStackTrace();
//			throw e;			
			throw new PayeeAlreadyExistsException("Payee Id already exists");
		}
		System.out.println("Payee added successfully");
		return "Payee added successfully";
		
	}

	@Override
	public Payee findPayeeService(int payeeNo)
	{ 			//throws PayeeNotFoundException{
		
		return payeeRepo.findPayee(payeeNo);
	}

//	@Override
//	public Set<Payee> findPayeesService(int payeeNo) {
//		System.out.println("Payee Service....Some scope of bussiness logic here...");
//		return payeeRepo.findPayee(payeeNo);
//	}

	@Override
	public Set<Payee> findAllPayeesService() 
	{
		
		return payeeRepo.findAllPayees();
	}

	@Override
	public String removePayeeService(int payeeNo) { // throws PayeeNotFoundException {
		Payee p =payeeRepo.findPayee(payeeNo);
		if(p!=null)
		{
			payeeRepo.removePayee(p.getPayeeId());
			}
//		else {
//			throw new PayeeNotFoundException("Payee Not Found");
//		}
		return "Payee Deleted successfully";
	}

}