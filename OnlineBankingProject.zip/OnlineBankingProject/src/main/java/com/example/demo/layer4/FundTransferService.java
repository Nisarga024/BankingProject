package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;
import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer4.exception.FundTransferAlreadyExistsException;

@Service
public interface FundTransferService 
{	
	String addTransactionService(FundTransfer fundtransRef)throws FundTransferAlreadyExistsException;   // add/create    
	FundTransfer findTransactionsService(int fundNo); // throws FundTransferNotFoundException;
	Set<FundTransfer> findAllTransactionsService(); 
}
