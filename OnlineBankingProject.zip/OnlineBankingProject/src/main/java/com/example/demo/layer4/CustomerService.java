package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;


@Service
public interface CustomerService {


	String addCustomerService(Customer custRef)throws CustomerAlreadyExistsException;
	Customer findCustomerService(int custNo);
	Set<Customer>findAllCustomersService(); 
	
}