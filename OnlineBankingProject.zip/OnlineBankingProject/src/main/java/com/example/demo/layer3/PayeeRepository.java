
package com.example.demo.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;


import com.example.demo.layer2.Payee;

@Repository
public interface PayeeRepository
{
	void addPayee(Payee payeeRef);   //C - add/create
	Payee findPayee(int payeeNo); 
	Set<Payee> findPayees(int payeeNo);
	Set<Payee>findAllPayees(); //R - find/reading   //R - find all/reading all
	void removePayee(int payeeNo); //D - remove/delete
}