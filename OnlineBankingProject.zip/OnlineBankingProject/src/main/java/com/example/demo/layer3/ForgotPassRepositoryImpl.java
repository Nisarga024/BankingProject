package com.example.demo.layer3;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.ForgotPass;

@Repository
public class ForgotPassRepositoryImpl implements ForgotPassRepository
{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file


	@Transactional
	public Set<ForgotPass> findAllSecurity() 
	{
		Set<ForgotPass> forgotList;
		
		Query query = entityManager.createQuery("from Forgot_pass");
		forgotList = new HashSet(query.getResultList());
		return forgotList;
	}


	@Transactional
	public void addForgotPass(ForgotPass forgotRef)
	{
		entityManager.persist(forgotRef);
		
	}

	@Transactional
	public ForgotPass findForgotPassword(int forgotNo)
	{
		return null;
	}
	     
	
}
