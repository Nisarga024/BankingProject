package com.example.demo;



import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.ForgotPass;
import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer2.Payee;
import com.example.demo.layer2.Register;

import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer3.ForgotPassRepository;
import com.example.demo.layer3.FundTransferRepository;
import com.example.demo.layer3.PayeeRepository;
import com.example.demo.layer3.RegisterRepository;



@SpringBootTest
class OnlineBankingProjectApplicationTests {
	@Autowired
	RegisterRepository registerRepo;
	@Autowired
	PayeeRepository payeeRepo;
	@Autowired
	CustomerRepository customerRepo;
	@Autowired
	FundTransferRepository transferRepo;
	@Autowired
	ForgotPassRepository forgotRepo;
		

	@Test
	void addRegistration()    //adding register
	{ 
			Register register = new Register();
			
			register.setRefNo(1);
			register.setFname("NAVEEN");			
			register.setMname("");
			register.setLname("LAGADAPATI");
			register.setFathersName("Mr.Ganesh");
			register.setMobileNo(923146754);
			register.setEmail("naveen@gmail.com");		
			register.setAadharNo("4534564599");
			
			String str="1998-02-30";
			Date date=Date.valueOf(str);
			register.setDob(date);
			
			register.setResAddress("AndraPradesh");
			register.setPerAddress("AndraPradesh");
			register.setOccupation("Business");
			System.out.println("-----------------");
			registerRepo.addRegistration(register);
			System.out.println("....Registration Added!!.....");
	}
	
	@Test
	void addCustomer()  //adding customer
	{ 
			Customer customer=new Customer();
			ForgotPass forgotPass=new ForgotPass();
			Register register=new Register();
			
			customer.setCustId(100);
			customer.setAccNumber(21134);
			customer.setIniPassword("naveen1999");
			customer.setMasterBal(50000);
			customer.setAccType("savings");
			customer.setSecurityAns("joesph");
			forgotPass.setSecurityId(11);
			register.setRefNo(1);
			customer.setForgotPass(forgotPass);
			customer.setRegister(register);
			
			customerRepo.addCustomer(customer);
			System.out.println("....Customer Added!!.....");
	}
	
	@Test
	void addpayee() 			//adding Payee
	{  
		Payee payee=new Payee();
		Customer customer=new Customer();
		
		payee.setPayeeId(200);
		payee.setBnefName("Nisarga");
		payee.setBnefAccNo(58788);
		payee.setNickname("nisarga");
		customer.setCustId(100);
		payee.setCustomer2(customer);
		
		payeeRepo.addPayee(payee);
		System.out.println("....Payee Added!!.....");
			
	}
	@Test
	void addtransaction()   //adding FundTransfer
	{  
			FundTransfer fundtrans = new FundTransfer();
			Payee payee=new Payee();
			Customer customer=new Customer();
			
			fundtrans.setTransactionId(01);
			fundtrans.setTransactionType("IMPS");
			fundtrans.setAmountTrans(5000);
			String str="2021-05-22"; 			//sys date
			Date date=Date.valueOf(str);
			fundtrans.setTransactionDate(date);
			payee.setPayeeId(200);
			fundtrans.setPayee(payee);
			customer.setCustId(100);
			fundtrans.setCustomer1(customer);
			
			transferRepo.addTransaction(fundtrans);
			System.out.println("....Fund-Transfer Added!!.....");
			
		}

	
	@Test
	void getSingleRegistration()   //finding single registration By ServiceRefNo
	{
	
		Register register = registerRepo.findRegistration(4);
		System.out.println("............................... ");
		System.out.println("Service Ref.No : "+register.getRefNo());
		System.out.println(" F-Name        : "+register.getFname());
		System.out.println(" L-Name        : "+register.getLname());
		System.out.println(" M-Name        : "+register.getMname());
		System.out.println(" FATHER Name   : "+register.getFathersName());
		System.out.println(" Mobile number : "+register.getMobileNo());
		System.out.println(" Email         : "+register.getEmail());
		System.out.println(" Aadhar No     : "+register.getAadharNo());
		System.out.println(" DOB           : "+register.getDob());
		System.out.println(" Res-Address   : "+register.getResAddress());
		System.out.println(" Per-Address   : "+register.getPerAddress());
		System.out.println(" Occupation    : "+register.getOccupation());
		System.out.println("............................... ");
	}

		
	@Test
	void getSingleCustomer()  //finding single customers By CustID
	{ 
		
		Customer customer = customerRepo.findCustomers(1);
		System.out.println("------------------------------");
		System.out.println("cust id   : "+customer.getCustId());
		System.out.println("acc no    : "+customer.getAccNumber());
		System.out.println("ini pass  : "+customer.getIniPassword());
		System.out.println("bal       : "+customer.getMasterBal());
		System.out.println("acc type  : "+customer.getAccType());
		System.out.println("sec ans   : "+customer.getSecurityAns());
		System.out.println("forgo     : "+customer.getForgotPass().getSecurityId());
		System.out.println("reg       : "+customer.getRegister().getRefNo());
		System.out.println("------------------------------");
	}

	@Test
	void getSinglePayee()  //finding single payee By payeeID
	{  
		Payee payee = payeeRepo.findPayee(1);	
		System.out.println("------------------------------");
		System.out.println("Payee id  		 : "+payee.getPayeeId());
		System.out.println("Bnef Account No  : "+payee.getBnefAccNo());
		System.out.println("Bnef Name   	 : "+payee.getBnefName());
		System.out.println("Nick name 		 : "+payee.getNickname());
		System.out.println("cust id   		 : "+payee.getCustomer2().getCustId());
		System.out.println("------------------------------");
	}
	
	@Test
	void getSingleFundTransfer()   //finding single fund-transfer By TransactionID
	{   
		FundTransfer fundtrans = transferRepo.findTransaction(3);
		System.out.println("------------------------------");
		System.out.println("Transaction ID 	    : "+fundtrans.getTransactionId());
		System.out.println("Amount to transfer	: "+fundtrans.getAmountTrans());
		System.out.println("Transaction Date  	: "+fundtrans.getTransactionDate());
		System.out.println("Transaction Type	: "+fundtrans.getTransactionType());
		System.out.println("Payee ID  			: "+fundtrans.getPayee().getPayeeId());
		System.out.println("Cust ID			 	: "+fundtrans.getCustomer1().getCustId());
		System.out.println("------------------------------");
		
}
	
	@Test
	void findallRegistration()   //finding all Registration
	{
		Set<Register> registerSet = registerRepo.findRegistration();
		for(Register register :registerSet) 
		{
			System.out.println("------------------------------");
			System.out.println("service number: "+register.getRefNo());
			System.out.println(" F-Name       : "+register.getFname());
			System.out.println(" L-Name       : "+register.getLname());
			System.out.println(" M-Name       : "+register.getMname());
			System.out.println(" FATHER Name  : "+register.getFathersName());
			System.out.println(" Mobile number: "+register.getMobileNo());
			System.out.println(" Email        : "+register.getEmail());
			System.out.println(" Aadhar No    : "+register.getAadharNo());
			System.out.println(" DOB          : "+register.getDob());
			System.out.println(" Res-Address  : "+register.getResAddress());
			System.out.println(" Per-Address  : "+register.getPerAddress());
			System.out.println(" Occupation   : "+register.getOccupation());
			System.out.println("............................... ");
		}
	}
	
	@Test
	void findallCustomer()  //finding all Customer
	{
		Set<Customer> custSet = customerRepo.findAllCustomers();
		for(Customer customer :custSet) 
		{
			System.out.println("............................... ");
			System.out.println("customer id        : "+customer.getCustId());
			System.out.println("Account number     : "+customer.getAccNumber());
			System.out.println("Initial password   : "+customer.getIniPassword());
			System.out.println("Master balance     : "+customer.getMasterBal());
			System.out.println("Account type       : "+customer.getAccType());
			System.out.println("Security ans       : "+customer.getSecurityAns());
			System.out.println("Security ID        : "+customer.getForgotPass().getSecurityId());
			System.out.println("Service Ref.No     : "+customer.getRegister().getRefNo());
			System.out.println("............................... ");
		}
	}
	
	@Test
	void findallPayee()  //finding all Payee
	{
		Set<Payee> payeeSet = payeeRepo.findAllPayees();
		for(Payee payee :payeeSet)
		{
			System.out.println("............................... ");
			System.out.println("Payee ID            : "+payee.getPayeeId());
			System.out.println("Bnef Name           : "+payee.getBnefName());
			System.out.println("Bnef Account number : "+payee.getBnefAccNo());
			System.out.println("Nick Name           : "+payee.getNickname());
			System.out.println("Cust ID             : "+payee.getCustomer2().getCustId());
			System.out.println("............................... ");
		}
	}
	
	@Test
	void findallFundTransaction() //finding all fundTransaction
	{
		Set<FundTransfer> fundset = transferRepo.findAllTransactions();
		for(FundTransfer fundtransfer :fundset)
		{
			System.out.println("............................... ");
			System.out.println("Transaaction ID    : "+fundtransfer.getTransactionId());
			System.out.println("Transcation Type   : "+fundtransfer.getTransactionType());
			System.out.println("Ammount Transfer   : "+fundtransfer.getAmountTrans());
			System.out.println("Transaction Date   : "+fundtransfer.getTransactionDate());
			System.out.println("Cust ID            : "+fundtransfer.getCustomer1().getCustId());
			System.out.println("Payee ID           : "+fundtransfer.getPayee().getPayeeId());
			System.out.println("............................... ");		
		}
	}
	
	@Test
	void deleteRegistration()  // Delete Registration
    {
		transferRepo.removeTransaction(2);
        System.out.println("....Removed Successfully!!...");
    }
	@Test
	void deleteCustomer()  // Delete Customer
    {
		transferRepo.removeTransaction(2);
        System.out.println("....Removed Successfully!!...");
    }
	@Test
	void deletePayee()  // Delete Payee
    {
		payeeRepo.removePayee(2);
        System.out.println("....Removed Successfully!!.....");
    }
	
	@Test
	void deleteFundTransfer()  // Delete FundTransfer
    {
		transferRepo.removeTransaction(2);
        System.out.println("....Removed Successfully!!...");
    }
	@Test
	void searchingCustomerActivityFromRegistration()
	{ 							//finding reg-->cust-->payee-->fundtransfer
		Register register = registerRepo.findRegistration(4);
	
			System.out.println("service number: "+register.getRefNo());
			System.out.println(" F-Name       : "+register.getFname());
			System.out.println(" L-Name       : "+register.getLname());
			System.out.println(" M-Name       : "+register.getMname());
			System.out.println(" FATHER Name  : "+register.getFathersName());
			System.out.println(" Mobile number: "+register.getMobileNo());
			System.out.println(" Email        : "+register.getEmail());
			System.out.println(" Aadhar No    : "+register.getAadharNo());
			System.out.println(" DOB          : "+register.getDob());
			System.out.println(" Res-Address  : "+register.getResAddress());
			System.out.println(" Per-Address  : "+register.getPerAddress());
			System.out.println(" Occupation   : "+register.getOccupation());
			System.out.println("............................... ");
		
			Set<Customer>  custSet =register.getCustomers();	
			for (Customer customer : custSet) 
			{
				System.out.println("Customer ID    : "+customer.getCustId());
				System.out.println("Account Type   : "+customer.getAccType());
				System.out.println("Customer pass  : "+customer.getIniPassword());
				System.out.println("Customer Bal   : "+customer.getMasterBal());
				System.out.println("Security ans   : "+customer.getSecurityAns());
				System.out.println("Forgot pass id : "+customer.getForgotPass().getSecurityId());
				System.out.println("Service number : "+customer.getRegister().getRefNo());
				System.out.println("............................... ");
		
				Set<Payee> payeeSet = customer.getPayees();
				for (Payee payee : payeeSet)
				{
					System.out.println("payee id 	:"+payee.getPayeeId());
					System.out.println("Account no  :"+payee.getBnefAccNo());
					System.out.println("Name        :"+payee.getBnefName());
					System.out.println("Nick name   :"+payee.getNickname());
					System.out.println("cust id     :"+payee.getCustomer2().getCustId());	
					System.out.println("-----------------");
			
			
					Set<FundTransfer> fundSet = payee.getFundtransfers();
					for (FundTransfer fundtransfer : fundSet)
					{
						System.out.println("trans id :"+fundtransfer.getTransactionId());
						System.out.println("amt      :"+fundtransfer.getAmountTrans());
						System.out.println("type     :"+fundtransfer.getTransactionType());
						System.out.println("date     :"+fundtransfer.getTransactionDate());
						System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
						System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
						System.out.println("-----------------");
					}
				}
			}			
		}
	@Test
	void searchingCustomerActivity()
	{ 
		Customer customer= customerRepo.findCustomers(100);
		System.out.println("Customer ID    : "+customer.getCustId());
		System.out.println("Account Type   : "+customer.getAccType());
		System.out.println("Customer pass  : "+customer.getIniPassword());
		System.out.println("Customer Bal   : "+customer.getMasterBal());
		System.out.println("Security ans   : "+customer.getSecurityAns());
		System.out.println("Forgot pass id : "+customer.getForgotPass().getSecurityId());
		System.out.println("Service number : "+customer.getRegister().getRefNo());
		
		Set<Payee> payeeSet = customer.getPayees();
		for (Payee payee : payeeSet)
		{
			System.out.println("payee id 	:"+payee.getPayeeId());
			System.out.println("Account no  :"+payee.getBnefAccNo());
			System.out.println("Name        :"+payee.getBnefName());
			System.out.println("Nick name   :"+payee.getNickname());
			System.out.println("cust id     :"+payee.getCustomer2().getCustId());	
			System.out.println("-----------------");
	
	
			Set<FundTransfer> fundSet = payee.getFundtransfers();
			for (FundTransfer fundtransfer : fundSet)
			{
				System.out.println("trans id :"+fundtransfer.getTransactionId());
				System.out.println("amt      :"+fundtransfer.getAmountTrans());
				System.out.println("type     :"+fundtransfer.getTransactionType());
				System.out.println("date     :"+fundtransfer.getTransactionDate());
				System.out.println("payee id :"+fundtransfer.getPayee().getPayeeId());
				System.out.println("cust id  :"+fundtransfer.getCustomer1().getCustId());
				System.out.println("-----------------");
			}
		}
	}
}