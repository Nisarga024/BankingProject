import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { register, registerDTO } from '../register';
import { RegisterService } from '../register.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  router: any;

   constructor(private css: RegisterService) { }
ngOnInit():void { }


 
//  addRegister(myReg:registerDTO){
//     this.css.addRegistrationService(myReg).subscribe((data:any)=>{
//       if(data!=null){
//         alert(this.myReg);
//         console.log(data); 
//          alert('data'+data); 
//         alert("adding is successful");
      
//       }else{
    
//       alert("something went wrong");
//       // console.log(err);
//   }
//   })
// }
myReg:registerDTO=new registerDTO(); 
addRegister(){
  this.css.addRegistrationService(this.myReg).subscribe((data: string) => {
      if(data != null) {  // SUBSSCRIBE THE ADD ALSO 
          alert("Registration is successful");
      //    this.router.navigate(["/register/login"]); //IGNORE THIS ROUTING
      }
  }, (err) => {
      alert("something went wrong");
      console.log(err);
  })
}
  // registerDTO(registerDTO: any) {
  //   throw new Error('Method not implemented.');
  // }

  // findRegisterService(regNo:number){
  //   this.regServ.findRegisterService(regNo).subscribe((data)=>{
    
  //     if(data!=null){
  //       this.tempResult=data;
  //     }else{
  //       alert("unable to fetch");
  //     }
  // })}

  // findAllRegistrationService(){
  //   this.regServ.findAllRegistrationService().subscribe((data)=>{
  //     if(data!=null){
  //       this.tempResult=data;
  //       sessionStorage.setItem("details",JSON.stringify(data));
  //     }
  //     else{
  //       alert("unable to fetch");
  //     }
  //   })
  // }


// }
}
