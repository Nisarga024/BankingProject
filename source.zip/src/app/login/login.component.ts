import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // existingUser: Login
  // constructor(public auth: LoginService) {
  //    this.existingUser = new Login()
  // }
  // signIn(signInForm:any){
  //   this.auth.signIn(this.existingUser)
  // }

  // ngOnInit(): void {
  // }
username:string | undefined ;
password:string | undefined ;



  constructor(private router:Router ,private ccs:LoginService) {   
   }
  
  ngOnInit(): void {
  }
//   logIn() :void {
//     if(this.username =="sravani" && this.password =="123")
//     {
//     this.router.navigate(["dashboard"]);
//     }
//     else{
//   alert("invalid");
//     }
// }
temp:Login =new Login();
loginValidate(){
  this.ccs.findUserByUserIDPasswordService(this.temp).subscribe((data:Login)=>{
if(data!=null){
  this.temp=data;
  console.log(data);
  this.router.navigate(["dashboard"]);
  alert('login successfull');
}else{
  alert('login denied');
}
  })
}
  
 


}
