export class register{
    refNo:number | undefined
    aadharNo:string | undefined;
    dob:Date | undefined;
    email:string | undefined;
    fathersName:string | undefined;
    fname:string | undefined;
    lname:string | undefined;
    mname:string | undefined;
    mobileNo:number | undefined;
    occupation:string | undefined;
    perAddress:string | undefined;
    resAddress:string | undefined;
   }

   export class registerDTO{
    //; refNo:number | undefined
     aadharNo:string | undefined;
     dob:Date | undefined;
     email:string | undefined;
     fathersName:string | undefined;
     fname:string | undefined;
     lname:string | undefined;
     mname:string | undefined;
     mobileNo:number | undefined;
     occupation:string | undefined;
     perAddress:string | undefined;
     resAddress:string | undefined;
    }