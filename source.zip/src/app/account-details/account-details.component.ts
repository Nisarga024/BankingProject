import { Component, OnInit } from '@angular/core';
import { register } from '../register';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  constructor(private resServ:RegisterService) { }

  ngOnInit(): void {
  }

  temp: register | undefined ;
  findReg(regNo :number)
  {
    this.resServ.findRegisterService(regNo).subscribe((data:register)=>{
    // if(data!=null)
    // {
        this.temp=data;
        console.log(data);
        sessionStorage.setItem("get all registration",JSON.stringify(data)); // storing this on browser session
    
  }, (err) => {
      console.log(err);
  });
    // else{
    //     alert("unable to fetch");
}
}
