import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Login } from './login';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

 

  constructor(private myHttp: HttpClient) { }

 findUserByUserIDPasswordService(login :Login):Observable<Login>
 {
   return this.myHttp.post<Login>("http://localhost:8080/loginUser",login);
 }
}