import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payee } from './payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {

  constructor(private myHttp: HttpClient) { }

  addPayeeService(myPay :Payee){
    return this.myHttp.post("http://localhost:8080/addPay/",myPay,{responseType:'text'}); 
 }

//  findPayeeService(regNo:number):Observable<register>{
//    return this.myHttp.get<register>("http://localhost:8080/getReg/"+regNo);
//  }
//  removePayeeService():Observable<register[]>{
//    alert("Displaying all Registration");
//    return this.myHttp.get<register[]>("http://localhost:8080/getRegs");
//  }
 
 findAllPayeesService():Observable<Payee[]>{
  alert("All available Payee");
  return this.myHttp.get<Payee[]>("http://localhost:8080/getPays");
}
}
