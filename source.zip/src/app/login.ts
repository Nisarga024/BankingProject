export class Login {
    custId: string | undefined
    iniPassword: string | undefined


}