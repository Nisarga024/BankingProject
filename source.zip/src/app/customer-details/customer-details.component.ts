import { Component, OnInit } from '@angular/core';
import { CustomerDTO } from '../customer';
import { CustomerService } from '../customer.service';
import { register } from '../register';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  constructor(private custServ:CustomerService) { }

  ngOnInit(): void {
  }
  custRef:CustomerDTO=new CustomerDTO(); 
  addCustomer()
  {
 
    this.custServ.addCustomerService(this.custRef).subscribe((data: string) => {
        if(data != null) {  // SUBSSCRIBE THE ADD ALSO 
            alert("Customer generated!");
        //    this.router.navigate(["/register/login"]); //IGNORE THIS ROUTING
        }
    }, (err) => {
        alert("something went wrong");
        console.log(err);
    })
  }
  ShowMe2:boolean=false
toogleTag2()
{
  this.ShowMe2=!this.ShowMe2;
  
}
}
