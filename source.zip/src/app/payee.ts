import { Customer } from "./customer";

export class Payee
{
    payeeId:number | undefined;
    bnefAccNo:string | undefined;
    bnefName:number | undefined;
    nickname:string | undefined;
    customer2:Customer | undefined;
}
