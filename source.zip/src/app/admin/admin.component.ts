import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  username:string | undefined ;
password:string | undefined ;



  constructor(private router:Router ) {   
   }
  
  ngOnInit(): void {
  }
  logIn() :void {
    if(this.username =="admin" && this.password =="123")
    {
    this.router.navigate(["admindashboard"]);
    }
    else{
  alert("invalid");
    }

}
}